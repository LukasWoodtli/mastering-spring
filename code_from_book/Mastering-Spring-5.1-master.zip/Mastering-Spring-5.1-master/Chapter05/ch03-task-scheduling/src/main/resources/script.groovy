import com.mastering.spring.dynamic.scripting.Planet
class Earth implements Planet {
    public long getDistanceFromSun() {
        return 100000000
    }
}
