package com.mastering.spring.dynamic.scripting;
public interface SecretMessenger {
    String getKey();
}