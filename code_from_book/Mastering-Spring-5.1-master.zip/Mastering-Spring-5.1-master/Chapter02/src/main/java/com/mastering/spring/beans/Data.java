package com.mastering.spring.beans;

public class Data {
  private int value;

  public Data(int value) {
    super();
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }

}
