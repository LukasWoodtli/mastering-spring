package com.mastering.spring.business;

import com.mastering.spring.beans.User;

public interface BusinessService {
  long calculateSum(User user);
}
