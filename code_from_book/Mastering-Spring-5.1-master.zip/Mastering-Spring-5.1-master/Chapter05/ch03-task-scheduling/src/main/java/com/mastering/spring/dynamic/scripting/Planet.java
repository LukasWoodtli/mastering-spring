package com.mastering.spring.dynamic.scripting;
public interface Planet {
    long getDistanceFromSun();
}